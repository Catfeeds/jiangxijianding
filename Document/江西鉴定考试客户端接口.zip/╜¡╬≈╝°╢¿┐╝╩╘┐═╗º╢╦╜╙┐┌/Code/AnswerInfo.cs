﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ETLExamPlatform.Proxy.BusiModel
{
    public class AnswerInfo
    {
        public string ExamCode { get; set; }
        public string SafeCode { get; set; }
        public string RandomQueIds { get; set; } 
        public string Answer { get; set; }
        public double Score { get; set; }

        public List<BlankFill> BlankFillAns { get; set; }
        public List<JieDa> ShortAns { get; set; }
        public List<JieDa> DiscussAns { get; set; }
        public List<JieDa> AnalyzeAns { get; set; }
    }


    public class BlankFill
    {
        public string QuestionId { get; set; }
        public List<BlankFillItem> Content { get; set; }
    }
    public class BlankFillItem
    {
        public int SortId { get; set; }
        public string Content { get; set; }
    }

    public class JieDa
    {
        public string QuestionId { get; set; }
        public string Content { get; set; }
    }
}
